/* $Id: HardwareSerial.h 1152 2011-06-06 21:50:10Z bhagman $
||
|| @author         Brett Hagman <bhagman@wiring.org.co>
|| @url            http://wiring.org.co/
||
|| @description
|| | Provided for compatibility.
|| |
|| | Wiring Core API
|| #
||
|| @license Please see cores/Common/License.txt.
||
*/

#include "WHardwareSerial.h"
