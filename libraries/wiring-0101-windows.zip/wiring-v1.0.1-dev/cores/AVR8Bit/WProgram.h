/* $Id: WProgram.h 1152 2011-06-06 21:50:10Z bhagman $
||
|| @author         Alexander Brevig <abrevig@wiring.org.co>
|| @url            http://wiring.org.co/
||
|| @description
|| | Provided for compatibility.
|| |
|| | Wiring Core API
|| #
||
|| @license Please see cores/Common/License.txt.
||
*/

#warning "You should #include <Wiring.h> instead of <WProgram.h> in your code"
#include <Wiring.h>